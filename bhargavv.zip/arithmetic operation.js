let n1=20 , n2=30;
var sum=n1+n2;
var sub=n1-n2;
var div=n1/n2;
var mul=n1*n2;
var mod=n1%n2;

document.write("<br/>sum:", sum+"<br/>mul:",sub+"<br/>div:",div+"<br/>mul:",mul+"<br/>mod",mod);
