let s1="silveroak";
let s2="oak";
let s3=s1+" "+s2;
document.write(s3);