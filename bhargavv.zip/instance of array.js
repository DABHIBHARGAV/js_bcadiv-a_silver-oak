var a=["silver" , "oak"];
document.write(a instanceof Array);

document.write("<br/>");


class rectangle{
    constructor(height,width){
    this.height=height;
    this.width=width;
    }
}

var R=new rectangle(30,20);
document.write(R instanceof rectangle);
document.write("<br/>");
document.write(R.height+R.width);
